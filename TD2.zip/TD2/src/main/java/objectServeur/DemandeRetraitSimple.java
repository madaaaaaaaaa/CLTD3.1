package objectServeur;

/**
 * Implantation de la stratégie de retrait simple
 *
 */
public class DemandeRetraitSimple implements IDemandeRetrait {

    @Override
    public int demandeRetrait(int unRetrait, IBanque b) {
        int valeurRetiree = unRetrait;
        b.getLeCompte().setSomme(b.getLeCompte().getSomme() - unRetrait);
        b.faireOperation("Retrait simple " + unRetrait);
        return valeurRetiree;
    }
}
