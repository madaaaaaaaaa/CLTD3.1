package objectServeur;

public interface IObject {

}
