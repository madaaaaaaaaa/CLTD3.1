package objectServeur;

import java.io.PrintStream;

import static java.lang.Integer.parseInt;

public class ProtocoleRetrait implements IProtocole {

    private int valeurDemandee;
    private ServeurTCP monServeur;
    private PrintStream os;

    public ProtocoleRetrait(int valeur, ServeurTCP serveur, PrintStream ps){
        valeurDemandee = valeur;
        monServeur = serveur;
        os = ps;
    }

    public void run(){
        System.out.println(" valeur demandee  " + valeurDemandee);

        int valeurRetrait = ((IBanque) monServeur.getObjetCentral()).demandeRetrait(valeurDemandee);

        String valeurExpediee = "" + valeurRetrait;
        System.out.println(" Retrait dans serveur " + valeurExpediee);

        os.println(valeurExpediee);

        System.out.println(monServeur);
    }
}
