package objectServeur;

import java.io.PrintStream;

public class ProtocoleDepot implements IProtocole {

    private int valeurDeposee;
    private ServeurTCP monServeur;
    private PrintStream os;

    public ProtocoleDepot(int valeur, ServeurTCP serveur, PrintStream ps){
        valeurDeposee = valeur;
        monServeur = serveur;
        os = ps;
    }

    public void run(){
        System.out.println(" valeur demandee  " + valeurDeposee);

        int valeurDepot = ((IBanque) monServeur.getObjetCentral()).demandeDepot(valeurDeposee);

        String valeurExpediee = "" + valeurDepot;
        System.out.println(" Depot dans serveur " + valeurExpediee);

        os.println(valeurExpediee);

        System.out.println(monServeur);
    }
}
