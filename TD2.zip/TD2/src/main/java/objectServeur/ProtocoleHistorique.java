package objectServeur;

import java.io.PrintStream;

public class ProtocoleHistorique implements IProtocole {

    private int valeurDemandee;
    private ServeurTCP monServeur;
    private PrintStream os;

    public ProtocoleHistorique(ServeurTCP serveur, PrintStream ps){
        monServeur = serveur;
        os = ps;
    }

    public void run(){
        String outputString = "Liste des operations :\n";
        for (String h : ((IBanque) monServeur.getObjetCentral()).getHistoriqueOperations()) {
            outputString = outputString + h + "\n";
        }
        System.out.println(" Liste a envoyer : \n " + outputString);
        os.println(outputString);
        os.flush();
    }
}
