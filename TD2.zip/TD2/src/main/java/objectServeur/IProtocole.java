package objectServeur;

import java.io.PrintStream;

public interface IProtocole {

    public void run();
}
