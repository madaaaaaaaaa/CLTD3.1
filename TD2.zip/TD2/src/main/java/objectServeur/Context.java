package objectServeur;

import java.io.IOException;
import java.io.PrintStream;

import static java.lang.Integer.parseInt;

public class Context {
    public String comType;
    public ServeurTCP monServeur;
    public PrintStream os;

    public Context(String type, ServeurTCP serveur, PrintStream ps){
        comType = type;
        monServeur = serveur;
        os = ps;
    }

    public IProtocole run(String value) throws IOException {
        if (comType.contentEquals("retrait")) {
            ProtocoleRetrait protocoleRetrait = new ProtocoleRetrait(parseInt(value), monServeur, os);
            return protocoleRetrait;
        }
        if (comType.contentEquals("depot")) {
            ProtocoleDepot protocoleDepot = new ProtocoleDepot(parseInt(value), monServeur, os);
            return protocoleDepot;
        }
        if (comType.contentEquals(automateClient.Historique.requeteHisto)) {
            ProtocoleHistorique protocoleHistorique = new ProtocoleHistorique(monServeur, os);
            return protocoleHistorique;
        } else {
            os.println("Erreur de protocole..... \n");
            throw new IOException("Erreur de protocole");
        }
    }
}
