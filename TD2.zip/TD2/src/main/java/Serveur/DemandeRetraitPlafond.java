package Serveur;

/**
 * Implantation de la stratégie de dépôt temporisé
 *
 */

public class DemandeRetraitPlafond implements IDemandeRetrait {

    @Override
    public int demandeRetrait(int unRetrait, IBanque b) {
        int plafond = b.getLeCompte().getPlafond();
        int valeurRetiree = unRetrait;
        if (unRetrait>plafond) {
            valeurRetiree = plafond;
        }
        b.getLeCompte().setSomme(b.getLeCompte().getSomme() - valeurRetiree);
        b.faireOperation("Retrait plafond " + valeurRetiree);
        return valeurRetiree;
    }
}
