// Indépendant - fini
package Serveur;

/**
 * Une API simple, qui représente la stratégie (générique) pour une requête
 *
 */

public interface IRequete {

    public int demandeRequete(int uneRequete, IContexte a);
}
