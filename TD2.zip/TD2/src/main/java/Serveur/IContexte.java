// Indépendant - fini
package Serveur;

import banqueServeur.CompteBancaire;

import java.util.ArrayList;

/**
 * API représentant une application quelconque
 *
 */
public interface IContexte {

    public ArrayList<String> getHistoriqueOperations();

}