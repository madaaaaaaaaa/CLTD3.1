package Serveur;

/**
 * Contient la méthode main()
 * 
 */
public class MainServeur {

	/**
	 * Méthode principale : lance le programme
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Application monApplication = new Application();
		ApplicationGUI applicationGUI = new ApplicationGUI(monApplication);
		applicationGUI.initGui();
		monApplication.ouvrirApplication();

		Banque maBanque = new Banque(10000, new DemandeDepotSimple(), new DemandeRetraitPlafond());
		/* BanqueGUI remplace MontantBanqueGUI des TPs precedents */
		BanqueGUI banqueGUI = new BanqueGUI(maBanque);
		banqueGUI.initGui();
		maBanque.ouvrirBanque();

	}
}
