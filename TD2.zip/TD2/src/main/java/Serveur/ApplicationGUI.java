package Serveur;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Une interface graphique qui affiche notre application.
 *
 */

public class ApplicationGUI extends javax.swing.JFrame {

    //StrategieUI strategieUI;
    //SommeUI sommeUI;

    public ApplicationGUI() {
        super();
    }

    public ApplicationGUI(Application a) {
        super();
        //strategieUI = new StrategieUI(b, this);
        //sommeUI = new SommeUI(b, this);
    }

    public void initGui() {
    }

    /*
     * --------------------------------------------------------------- Accessors for
     * fields that update
     * ---------------------------------------------------------------
     */

}

