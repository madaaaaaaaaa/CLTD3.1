# conception-logicielle-td2-strategie-partielle
Ce repo contient le code de départ avec une implantation partielle du Pattern stratégie
